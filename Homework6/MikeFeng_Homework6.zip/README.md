 [已完成] 提交格式正确，包含所有需要的文件；代码可以在虚拟机下正确
编译运行。
• [已完成] 包围盒求交：正确实现光线与包围盒求交函数。
• [已完成] BVH 查找：正确实现 BVH 加速的光线与场景求交。
• [已完成] SAH 查找：自学 SAH(Surface Area Heuristic) , 正
确实现 SAH 加速，并且提交结果图片，并在 README.md 中说明 SVH 的实现
方法，并对比 BVH、SVH 的时间开销。

参考资料已经列在comment里，图片在./image 下面
关于SAH的个人理解请参考这篇自己写的
https://trite-peanut-09f.notion.site/1f89d131eca14a3f8599c06f2678ebae

