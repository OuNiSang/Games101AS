
 [CHECK] 提交格式正确，包含所有需要的文件；代码可以在虚拟机下正确
编译运行。

 [CHECK] Path Tracing：正确实现 Path Tracing 算法，并提交分辨率
不小于 512*512，采样数不小于 8 的渲染结果图片。

提交了两张SPP分别为8和16的，分辨率为784*784，计算时间忘记记录了，16 SPP 多线程我记得是8min左右

 [CHECK]  多线程：将多线程应用在 Ray Generation 上，注意
实现时可能涉及的冲突。

通过修改Render function实现

[NOT FINISHED]Microfacet：正确实现 Microfacet 材质，并提交可
体现 Microfacet 性质的渲染结果。